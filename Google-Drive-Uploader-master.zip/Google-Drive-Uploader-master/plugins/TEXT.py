

# Here is Your Drive Folder Name You can Replace it with Your Desire name(Optional)
drive_folder_name = "GDriveUploaderBot"


# Enter Your Mega email And Pass (Required)
MEGA_EMAIL = "bearyan8@yandex.com"
MEGA_PASSWORD = "bearyan8@yandex.com"


START = " Hi {}  \nI am Drive Uploader Bot . Please Authorise To use me .By using /auth \n\n For more info /help \n\n Third-Party Website \n Support Added /update \n\n For Bot Updates  \n <a href ='https://t.me/aryan_bots'>Join Channel</a>\nPlease Report Bugs  @aryanvikash"

HELP = """   <b>AUTHORISE BOT</b> 
       Use  /auth Command Generate
       Your Google Drive Token And 
       Send It To Bot  
<b> You Wanna Change Your Login 
        Account ?</b> \n
        You Can Use /revoke 
        command            
<b>What I Can Do With This Bot? </b>
            You Can Upload Any Internet
            Files On Your google
            Drive Account.
<b> Links Supported By Bot</b>
            * Direct Links 
            * Openload links [Max Speed 
              500 KBps :(   ]
            * Dropbox links 
            *  Mega links
            
            + More On Its way:)
                
Bug Report @aryanvikash
        """
DP_DOWNLOAD = "Dropbox Link !! Downloading Started ..."
OL_DOWNLOAD = "Openload Link !! Downloading Started ... \n Openload Links Are Extremely Slow"
PROCESSING = "Processing Your Request ...!!"
DOWN_TWO = True
DOWNLOAD = "Downloading Started ..."
DOWN_MEGA = "Downloading Started... \n  Mega Links are \n Extremely Slow :("
DOWN_COMPLETE = "Downloading complete !!"
NOT_AUTH = "You Are Not Authorised To Using this Bot \n\n Please Authorise Me Using /auth  \n\n @aryanvikash"
REVOKE_FAIL = "You Are Already UnAuthorised \n. Please Use /auth To Authorise \n\n report At @aryanvikash "
AUTH_SUCC = "Authorised Successfully  !! \n\n Now Send me A direct Link :)"
ALREADY_AUTH = "You Are Already Authorised ! \n\n Wanna Change Drive Account? \n\n Use /revoke \n\n report At @aryanvikash "
AUTH_URL = '<a href ="{}">Vist This Url</a> \n Generate And Copy Your Google Drive Token And Send It To Me'
UPLOADING = "Download Complete !! \n Uploading Your file"
REVOKE_TOK = " Your Token is Revoked Successfully !! \n\n Use /auth To Re-Authorise Your Drive Acc. "
# DOWN_PATH = "Downloads\\" #windows path
DOWN_PATH = "Downloads/"  # Linux path
DOWNLOAD_URL = "Your File Uploaded Successfully \n\n <b>Filename</b> : {} \n\n <b> Size</b> : {} MB \n\n <b>Download</b> {}"
AUTH_ERROR = "AUTH Error !! Please  Send Me a  valid Token or Re - Authorise Me  \n\n report At @aryanvikash"
OPENLOAD = True
DROPBOX = True
MEGA = True


UPDATE = """ <b> Update  on  27.07.2019</b>
            * MEGA LINK added
            * Error Handling Improved

<b> Links Supported By Bot</b>
            * Direct Links 
            * Openload links [Max Speed 
              500 KBps :(   ]
            * Dropbox links 
            *  Mega links (only files)
            
            + More are in way:) """
